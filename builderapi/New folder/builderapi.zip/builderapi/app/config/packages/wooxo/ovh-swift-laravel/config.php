<?php

return array(
    'username' => 'z4HqvBkGcFsk',
    'password' => 'k89mrWKb6qZX6MHUYtP29tHGnBXGGuJ2',
    'region' => 'UK1',
    'tenantId' => '0a7df15dd5264215a6ec169ba55ea31c',
    'container' => 'cloud-madhu-album'
);
