<?php
return [
	
	'CDN_URL' => 'https://pull-515.5centscdn.com/v1/AUTH_0a7df15dd5264215a6ec169ba55ea31c/cloud-madhu-album',
	'OVH_URL' => 'https://storage.uk1.cloud.ovh.net/v1/AUTH_0a7df15dd5264215a6ec169ba55ea31c/cloud-madhu-album/',
	
];