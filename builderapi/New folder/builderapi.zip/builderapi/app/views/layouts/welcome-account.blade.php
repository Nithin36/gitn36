<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<table align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" style="background:#ffffff" width="100%">
    <tbody>

    <tr>
        <td>
            <table align="center" border="0" cellpadding="0" cellspacing="0"  style="padding:0 5px" width="570">
                <tbody>
                <tr>
                    <td align="center" style="padding:40px 20px 30px 20px;text-align:center;font-size:14px;color:#000;line-height:24px" valign="middle" width="100%">
                        <img alt="" border="0" height="57" src="https://www.floatalbums.com/assets/images/170.png" style="vertical-align:bottom;border:none;max-width:100%;outline:none!important" width="213"> </td>
                </tr>

                <tr>
                    <td align="center" style="padding:0 20px;text-align:center;font-size:25px;color:#000;line-height:30px;font-weight:600" valign="middle" width="100%">
                        Welcome to Floatalbums !</td>
                </tr>

                <tr>
                    <td height="30" width="100%">
                        &nbsp;</td>
                </tr>

                <tr>
                    <td style="padding:0 20px;text-align:justify;font-size:16px;color:#000;line-height:24px" valign="middle" width="100%">
                        Hi there,</td>
                </tr>
                <tr>
                    <td height="15" width="100%">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td style="padding:0 20px;text-align:justify;font-size:16px;color:#000;line-height:24px" valign="middle" width="100%">
                        We are excited to have you join our Float album platform and community of creative professionals worldwide!</td>
                </tr>
                <!--<tr>-->
                <!--<td height="15" width="100%">-->
                <!--&nbsp;</td>-->
                <!--</tr>-->
                <tr>
                    <td style="padding:0 20px;text-align:justify;font-size:16px;color:#000;line-height:24px" valign="middle" width="100%">
                        Please check your mail inbox for activation link to activate your Floatalbum account.</td>
                </tr>




                <tr>
                    <td>
                        <table border="0" cellpadding="0" cellspacing="0"  width="100%">
                            <tbody>




                            <tr>
                                <td align="left" style="padding:0 20px;text-align:left;font-size:16px;color:#000;line-height:24px" valign="middle" width="100%">
                                    Again we are thrilled to have you as our customer and looking forward to help you in generating more leads for your business !</td>
                            </tr>
                            <tr>
                                <td height="30" width="100%">
                                    &nbsp;</td>
                            </tr>


                            <tr align="">
                                <td>
                                    <table>
                                        <tbody>
                                        <tr>

                                            <td align="left" style="padding:0 5px;text-align:left;font-size:16px;color:#000;line-height:24px" valign="middle" width="100%">
                                                &nbsp;&nbsp;Cheers,<br>
                                                &nbsp;&nbsp;Floatalbums Team</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height="30" width="100%">
                                    &nbsp;</td>
                            </tr>


                            <tr>
                                <td height="10" width="100%">
                                    &nbsp;</td>
                            </tr>

                            <tr>
                                <td height="30" width="100%">
                                    &nbsp;</td>
                            </tr>

                            <tr>
                                <td height="20" width="100%">
                                    &nbsp;</td>
                            </tr>

                            <tr>
                                <td height="50" width="100%">
                                    &nbsp;</td>
                            </tr>

                            </tbody>
                        </table>
                    </td>
                </tr></tbody>
            </table>

</body>
</html>